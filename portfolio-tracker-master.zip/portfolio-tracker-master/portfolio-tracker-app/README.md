# Portfolio Tracker Web Application #

This Single-Page Angular Web application manages and tracks performances of investment portfolios. 

#### Build & development ####

* npm install
* bower install
* grunt serve

![Swagger Docs](portfolio-tracker-app.png)
