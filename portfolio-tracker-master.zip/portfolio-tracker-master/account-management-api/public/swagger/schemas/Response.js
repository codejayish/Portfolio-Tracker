/**
 * @SwaggerDefinitions
 *   Response:
 *     type: object
 *     properties:
 *       outcome:
 *         type: object
 *         $ref: "#/definitions/Outcome"
 *       data:
 *         type: object
 */