/**
 * @SwaggerDefinitions
 *   ReturnStatus:
 *     type: object
 *     properties:
 *       message:
 *         type: string
 *       name:
 *         type: string
 */