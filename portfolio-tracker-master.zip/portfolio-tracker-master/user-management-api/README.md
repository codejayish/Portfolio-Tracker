# User Management API #

#### Provides the following capabilities ####
* Register user
* Update user information
* Authenticate users and generate JWT token

![Swagger Docs](swagger.png)
